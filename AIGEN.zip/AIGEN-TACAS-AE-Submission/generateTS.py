import argparse
import time
import math
import mpmath
import sys
import random
import os
import re
import collections

sys.setrecursionlimit(2147483647)  #this is the maximum possible: 2^31 - 1(signed integer)
""" Global variables """
bdd_tuple = dict()  # bdd_ID --> (level, left, right)
bdd_to_lit = dict()  # holds the aig literals of the bdds bdd_ID --> aig_lit
maxLevel = 0  # maximum varaible index
maxLit = 0  # maximum literal in the aig literals
var_nb = 0  # total nuumber of variables in the aiger file
input_nb = 0  # total number of inputs in the aiger
u_nb = 0  # number of uncontrollable input
c_nb = 0  # number of controllable input
fileName = ""  # aiger file to be generated
output_lit =0  # output fct literal
andGates = []  # list of tuples (ag left right)
latches = collections.OrderedDict()  #latch lit --> fct lit
seeds = [] # to save the used seeds
inputSeeds = [] # to store input latches and output functions seeds if any
oseed = 0 # to store the seed for the selected variables in the output function
oseedVars = [] # to store the selected variables in the output function
noABC = 0
""" End of Global variables """

def computeDelta(sbn, bddID):
    #delta = 4*sbn*sbn -4*bdd_ID + 1
    nsq = mpmath.power(sbn,2)
    fournsq = mpmath.fmul(nsq,4)
    fourk = mpmath.fmul(4, bddID)
    sub = mpmath.fsub(fournsq, fourk)
    return mpmath.fadd(sub, 1)

def compute_sublevel_start(sbn, sli):
    #sls = sbn + n + 2(n-1) + 2(n-2)...2(n-sli)
    #sls = sbn + 2 * sbn * sli - sli*(sli + 1)
    p1 = mpmath.fadd(sbn, mpmath.fmul(2, mpmath.fmul(sbn, sli)))
    p2 = mpmath.fmul(sli, mpmath.fadd(sli, 1))
    return mpmath.fsub(p1,p2)

def ComputeASol(sbn, sqrtdelta):
    #sli = math.ceil(((2*sbn - 1 - sqdelta)/2) - 1)
    #x_2 - 1 <= i < x_2...i.e. i = ceil(x_2 - 1)
    two_n = mpmath.fmul(2, sbn)
    two_n = mpmath.fsub(two_n, 1)
    sol = mpmath.fdiv(mpmath.fsub(two_n, sqrtdelta),2)
    result = mpmath.fsub(sol, 1)
    return mpmath.ceil(result)

def construct_bdd(bdd_ID):
    if bdd_ID > 2 and bdd_ID not in bdd_tuple:
        level, left, right = getChildren(bdd_ID)
        #print "result", level, left, right
        bdd_tuple[bdd_ID] = level, left, right
        if left > 2:            ###############put this and the below check in the getChildren methooooooooooooooooooooooooooooooooooood############################################################
            construct_bdd(left)
        if right > 2:
            construct_bdd(right)

start = False
mpmath.pretty = True
#....we have precision problem
def getChildren(bdd_ID):
    tempStr = str(bdd_ID)
    input_length = len(tempStr)
    tempIdx = tempStr.find("+")
    if tempIdx > 0:
        input_length += int(tempStr[tempIdx+1:])
    mpmath.mp.dps = 2 * input_length  #we multiply by 2 as at some point we compute the cube of the number
    #first we should figure out the root node (variable index or level)
    #level = ceil(log(log(bdd_ID)))
    level = mpmath.ceil(mpmath.log(mpmath.log(bdd_ID, 2), 2))
    prev_lvl = level - 1
    smaller_bdd_nb = mpmath.power(2, mpmath.power(2, prev_lvl))
    sbn = smaller_bdd_nb  # just as a short hand...n
    #first we need to figure out in which sublevel does this number exist
    #now to compute the sublevel index sli or "i" for short we need to compute i
    #such that the below hold:
    #f1=n + 2(n-1) + 2(n-2)...2(n-i) < bdd_ID < f2=n + 2(n-1) + 2(n-2)...2(n-(i+1))
    #which turn out to be true when the smaller solution(racine) of f1 i.e. x_2
    #x_2 - 1 <= i < x_2...i.e. i = ceil(x_2 - 1) as we need integer solution
    #note that n + 2(n-1) + 2(n-2)...2(n-i) = n +2ni - 2i(i+1)/2
    #delta of f1 = 4n^2-4k +1
    #delta of f1 = 4*sbn*sbn -4*bdd_ID + 1
    delta = computeDelta(sbn, bdd_ID)
    sqdelta = mpmath.sqrt(delta)
    #2n-1 - sqrt(delta)/2 -1
    #sli = math.ceil(((2*sbn - 1 - sqdelta)/2) - 1)#....we have precision problem
    sli = ComputeASol(sbn, sqdelta)
    #we have to add 1 as our IDs starts from 1 instead of 0
    node1 = mpmath.fadd(sli, 1)  #sublevel index
    sls = 0  # sublevel start
    #sls = sbn + n + 2(n-1) + 2(n-2)...2(n-sli)
    #sls = sbn + 2 * sbn * sli - sli*(sli + 1)
    sls = compute_sublevel_start(sbn, sli)
    in_sublvl_index = mpmath.fsub(bdd_ID, sls)
    node2 = mpmath.fadd(node1, mpmath.ceil(mpmath.fdiv(in_sublvl_index,2)))
    #because of the ordering nature if this number is divisable by 2 or not
    #we decide which node is on the right and which one on the left
    if(mpmath.frac(mpmath.fdiv(in_sublvl_index,2)) != 0):
        return level,node1,node2
    return level,node2,node1

########################Converting BDD to AIG ##################################
#levelIndex starts with 1
def getAIGVarIdx(levelIndex):
    return 2 * int(levelIndex)  # level 0 contains 0 and 1

def getAIGVarIdx_out(levelIndex):
    return 2 * (int(levelIndex) + input_nb)  # level 0 contains 0 and 1

def getAIGVarIdx_out_random(levelIndex):
    return 2 * (oseedVars[int(levelIndex)] + input_nb)  # level 0 contains 0 and 1

def negateAIG_lit(aig_lit):
    return aig_lit ^ 1

def next_lit():
    """ :return: next possible literal """
    return (maxLit) + 2

def createAndGate(a_lit, b_lit):
    global maxLit
    if a_lit == 0 or b_lit == 0:
        return 0
    if a_lit == 1 and b_lit == 1:
        return 1
    if a_lit == 1:
        return b_lit
    if b_lit == 1:
        return a_lit
    if a_lit > 1 and b_lit > 1:
        a_b_lit = next_lit()
        andGates.append((a_b_lit, a_lit, b_lit))
        maxLit = a_b_lit
        return a_b_lit

def convertToAndGate(bdd_id, get_aig_lit):
    if bdd_id == 1 or bdd_id == 2:
        return bdd_id - 1
    level, left, right = bdd_tuple[bdd_id]
    x = get_aig_lit(level)  # bdd root variable
    #check if it is in cache first
    # bdd else fct
    x_e = -1
    if left in bdd_to_lit:
        x_e = bdd_to_lit[left]
    else:
        x_e = convertToAndGate(left, get_aig_lit)
    #check if it is in cache first
    # bdd then fct
    if right in bdd_to_lit:
        x_t = bdd_to_lit[right]
    else:
        x_t = convertToAndGate(right, get_aig_lit)
    # f = x*x_t + !x*x_e
    # f = !(!(x*x_t) * !(!x*x_e))
    nx = negateAIG_lit(x)
    x_x_t = createAndGate(x, x_t)
    nx_x_e = createAndGate(nx, x_e)
    neg_x_x_t = negateAIG_lit(x_x_t)
    neg_nx_x_e = negateAIG_lit(nx_x_e)
    temp = createAndGate(neg_x_x_t, neg_nx_x_e)
    f = negateAIG_lit(temp)
    bdd_to_lit[bdd_id] = f
    return f

def get_aiger_input(input_nb):
    input_list = []
    level = 1
    while level <= input_nb:
        input_list.append(getAIGVarIdx(level))
        level +=1
    return input_list

"""
var_nb = latches_nb + inputnb(controllable and uncontrollable)
This function creates for every latch an AIG, and it ceates an AIG
for the output function
"""
def generate_latches_fct(var_nb, latches_nb, outVarnb):

    global output_lit
    global bdd_to_lit
    global bdd_tuple
    global input_nb
    nb = latches_nb
    #generatedFcts = []
    #in an Aiger file the variables listing start with inputs then latches then
    #output. The first variable literal is 2. Therefore var_nb - latches_nb gives
    #the nb of inputs, so the first latch comes directly after the last input.
    #therefore we initialize latch_lit with the first latch literal
    latch_lit = getAIGVarIdx(var_nb - latches_nb + 1)
    while nb > 0:
        #generate a random number that corresponds to a unique boolean function.
        #top_var_index is the number of variables
        if(inputSeeds is None or len(inputSeeds) == 0 or len(inputSeeds) < len(seeds)):
            milli_sec = int(round(time.time() * 1000000))
            seeds.append(milli_sec)
            random.seed(milli_sec)
        else:
            currentSeed = inputSeeds[len(seeds)]
            seeds.append(currentSeed)
            random.seed(currentSeed)
        randomNumber = random.getrandbits(mpmath.power(2, top_var_index)) + 1
        fctID = randomNumber
        #the below create a list (bdd_tuple) where each item is a tuple (index,left,right)
        #therefore it resembles bdd unique table, and it avoids building the same
        #bdd twice.
        construct_bdd(randomNumber)
        #fctID maps to a tuple (index,left,right) in the list bdd_tuple
        fct_lit = convertToAndGate(fctID, getAIGVarIdx)
        #bdd_tuple.clear()
        latches[latch_lit] = fct_lit
        latch_lit += 2
        nb -= 1
    bdd_tuple.clear()
    bdd_to_lit.clear()
    #output_lit = generateSpecialOutput(latches_nb)
    output_lit = generateConfigurableOutput(input_nb, latches_nb, outVarnb)
    bdd_tuple.clear()

def generateSpecialOutput(latches_nb):
    #here we have only latches_nb instead of top_var_index as we dont want
    #the inputs to be part of the output(just to make things a bit simple)
    #-1 was a previous optimization to make the error region bigger
    if(inputSeeds is None or len(inputSeeds) == 0 or len(inputSeeds) < len(seeds)):
           milli_sec = int(round(time.time() * 1000000))
           seeds.append(milli_sec)
           random.seed(milli_sec)
    else:
       currentSeed = inputSeeds[len(seeds)]
       seeds.append(currentSeed)
       random.seed(currentSeed)
    randomNumber = random.getrandbits(mpmath.power(2, latches_nb - 1)) + 1
    fctID = randomNumber    
    construct_bdd(randomNumber)
    #The convertToAndGate function here takes as argument the function
    #"getAIGVarIdx_out" instead of "getAIGVarIdx" as the indices in the output
    #functions should be only latches indices.
    output_lit = convertToAndGate(fctID, getAIGVarIdx_out)
    output_lit = createAndGate(output_lit, getAIGVarIdx_out(latches_nb))
    return output_lit

"""
This method generates a random boolean function for the output.
It is configurable in a way that "outVarnb" represents the number of variables
in the function. The remaining variables {latches variables}\{outVarnb} we be
added to cube that conjuncted with the function. This way we can minimize the
size of the error region as much as possible. However the drawback is that we
don't know if the error will be reachable.
"""
def generateConfigurableOutput(input_nb, latches_nb, outVarnb):
    global oseed
    #here we have only outVarnb instead of top_var_index as we dont want
    #the inputs to be part of the output(just to make things a bit simple)
    #we need the +1 as our IDs starts from 1 instead of 0
    if(inputSeeds is None or len(inputSeeds) == 0 or len(inputSeeds) < len(seeds)):
           milli_sec = int(round(time.time() * 1000000))
           seeds.append(milli_sec)
           random.seed(milli_sec)
    else:
       currentSeed = inputSeeds[len(seeds)]
       seeds.append(currentSeed)
       random.seed(currentSeed)
    randomNumber = random.getrandbits(mpmath.power(2, outVarnb)) + 1
    fctID = randomNumber
    construct_bdd(randomNumber)
    
    needRandom = (latches_nb - outVarnb) <> 0
    if needRandom:
        if(oseed is None or oseed == 0):
            oseed = int(round(time.time() * 1000000))
            random.seed(oseed)
        else:
            random.seed(oseed)
        global oseedVars
        oseedVars = random.sample(xrange(1, latches_nb + 1), outVarnb)[:]
        oseedVars.insert(0,-1)#this as levelindex starts from 1
        output_lit = convertToAndGate(fctID, getAIGVarIdx_out_random)
    else:
        output_lit = convertToAndGate(fctID, getAIGVarIdx_out)
        #The convertToAndGate function here takes as argument the function
        #"getAIGVarIdx_out" instead of "getAIGVarIdx" as the indices in the output
        #functions should be only latches indices.

    #compute the cube of the remiaining variables of the latches if any
    cubeSize = latches_nb - outVarnb
    if cubeSize > 0:
        counter = 0
        while outVarnb + counter < latches_nb:
            output_lit = createAndGate(output_lit, getAIGVarIdx_out((outVarnb + counter +1)))
            counter += 1
    return output_lit

#u_nb : number of uncontrollable input
#c_nb : number of controllable input
#aiger format: header - c_inpt - u_inpt - latches - output - andgates - var_desc
def create_aiger(fileName, u_nb, c_nb):
    global output_lit
    input_list = get_aiger_input(u_nb + c_nb)
    content = input_list
    #laches
    for l in latches:
        content.append(str(l) + ' ' + str(latches[l]))
    #end of latches
    content.append(output_lit)
    #and gates
    for ag in andGates:
        content.append(str(ag[0]) + ' ' + str(ag[1]) + ' ' + str(ag[2]))
    #end of and gates
    #var description
    count = 0
    var_desc = []
    c_inputs = input_list[:c_nb]
    for c in c_inputs:
        var_desc.append('i' + str(count) + ' controllable_c_' + str(count))
        count += 1
    u_inputs = input_list[-u_nb:]
    for u in u_inputs:
        var_desc.append('i' + str(count) + ' u_' + str(count))
        count += 1
    count = 0
    for l in latches:
        var_desc.append('l' + str(count) + ' l_' + str(count))
        count += 1
    var_desc.append('o0' + ' err')
    content.extend(var_desc)
    #end of var description
    #header
    header = 'aag ' + str(maxLit/2) + ' ' + str(u_nb + c_nb) + ' ' \
        + str(len(latches)) + ' 1 ' + str(len(andGates))
    content.insert(0, header)
    #end of header
    fileOb = open(fileName, 'w+')
    for i in range(len(content)):
        fileOb.write(str(content[i]) + os.linesep)
    #writing comments
    fileOb.write('c' + os.linesep)
    for i in range(len(seeds) - 1):
        fileOb.write('latch ' + str(i) + ' seed: ' + str(seeds[i]) + os.linesep)
    fileOb.write('output ' + str(len(seeds) - 1) + ' seed: ' + str(seeds[len(seeds) - 1]) + os.linesep)
    fileOb.write('output vars seed: ' + str(oseed) + os.linesep)
    fileOb.close()

def ABCminimization(filePath):
    
    filePath = os.path.splitext(filePath)[0]
    #https://bitbucket.org/alanmi/abc/downloads
    abcCommand = """./abc -c \"read {0}.aig; strash; refactor -zl; rewrite -zl;
     strash; refactor -zl; rewrite -zl; strash; refactor -zl; rewrite -zl;
      dfraig; rewrite -zl; dfraig; write {1}.aig\" ./run > /dev/null"""
    abcCommand2 = """./abc -c \"read {0}.aig;
    balance; rewrite; refactor; balance; rewrite; rewrite -z; balance; refactor -z; rewrite -z; balance;
    balance; rewrite; refactor; balance; rewrite; rewrite -z; balance; refactor -z; rewrite -z; balance;
    write {1}.aig\" ./run > /dev/null"""
    #AIGER Toolset (http://fmv.jku.at/aiger/aiger-1.9.4.tar.gz)
    aagToaig = './aigtoaig {0}.aag {1}.aig'
    aigToaag = './aigtoaig {0}.aig {1}.aag'
    os.system(aagToaig.format(filePath, filePath))
    os.system(abcCommand.format(filePath, filePath))
    os.system(aigToaag.format(filePath, filePath))
    os.remove(filePath + '.aig')
####################End of Converting BDD to AIG ###############################

startTime = int(round(time.time() * 1000))
parser = argparse.ArgumentParser(description='Generating random aiger files')
parser.add_argument('-output','--outputFile',help='Output file name, ex: myFile.aag', required=True)
parser.add_argument('-c','--controllables', help='Number of controllable input variables', type=int, required=True)
parser.add_argument('-u','--uncontrollables',help='Number of uncontrollable input variables', type=int, required=True)
parser.add_argument('-l','--latches',help='Number of latches', type=int, required=True)
parser.add_argument('-o','--outputs',help='Number of output variables', type=int, required=True)
parser.add_argument('-seeds','--seeds',help='list of seeds to be used for the random number generation', nargs='+', type=int, required=False)
parser.add_argument('-oseed','--oseed',help='seed for the output function variables',type=int, required=False)
parser.add_argument('-noABC','--noABC',help='stop ABC tool',type=int, default=0, required=False)

args = parser.parse_args()
if args.controllables <= 0 or args.uncontrollables <= 0 or args.latches <= 0 or args.outputs <= 0:
    sys.exit("Error: c,u,l,o must be greater than 0!")
if args.outputs > args.latches :
    sys.exit("Error: Number of outputs variables must be smaller or equal to number of latches!")
#if not re.match('\w+\.aag',args.outputFile):
 #   sys.exit("Error: Output file name must look like the following : FileName.aag")
if args.seeds is not None and len(args.seeds) > 0 and len(args.seeds) > (args.latches + 1):
    sys.exit("Error: Number of seeds must be equal to l+1")    
fileName = args.outputFile
c_nb = args.controllables
u_nb = args.uncontrollables
latches_nb = args.latches
var_nb = c_nb + u_nb + latches_nb
input_nb = c_nb + u_nb
top_var_index = var_nb
outVarnb = args.outputs
inputSeeds = args.seeds
noABC = args.noABC
oseed = args.oseed
if inputSeeds is not None and len(inputSeeds) <> (latches_nb + 1):
    sys.exit("Number of seeds must be equal to l + 1")
maxLevel = top_var_index
# top(max) var index represents also the number of variables
maxLit = getAIGVarIdx(maxLevel)

startTime = int(round(time.time() * 1000))
generate_latches_fct(var_nb, latches_nb, outVarnb)
create_aiger(fileName, u_nb, c_nb)
print fileName + ': ', int(round(time.time() * 1000)) - startTime
if noABC == 0:
    from shutil import copyfile
    abcFileName = os.path.splitext(fileName)[0] +'_abc.aag'
    copyfile(fileName, abcFileName)
    ABCminimization(abcFileName)
    print fileName + '_abc: ', int(round(time.time() * 1000)) - startTime


