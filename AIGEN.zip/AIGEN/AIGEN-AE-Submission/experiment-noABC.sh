#!/bin/bash

> results.txt
> plots.tex

python3 aigen.py -bdd -output experiments/bdd_random_n1_4_4_7_7.aag -c 4 -u 4 -l 7 -o 7 -noABC >> results.txt
python3 aigen.py -bdd -output experiments/bdd_random_n2_4_4_7_7.aag -c 4 -u 4 -l 7 -o 7 -noABC >> results.txt
python3 aigen.py -bdd -output experiments/bdd_random_n3_4_4_7_7.aag -c 4 -u 4 -l 7 -o 7 -noABC >> results.txt

python3 aigen.py -dnf -output experiments/dnf_random_n1_4_4_7_7.aag -c 4 -u 4 -l 7 -o 7 -noABC >> results.txt
python3 aigen.py -dnf -output experiments/dnf_random_n2_4_4_7_7.aag -c 4 -u 4 -l 7 -o 7 -noABC >> results.txt
python3 aigen.py -dnf -output experiments/dnf_random_n3_4_4_7_7.aag -c 4 -u 4 -l 7 -o 7 -noABC >> results.txt

python3 aigen.py -bdd -output experiments/bdd_random_n1_4_5_7_7.aag -c 4 -u 5 -l 7 -o 7 -noABC >> results.txt
python3 aigen.py -bdd -output experiments/bdd_random_n2_4_5_7_7.aag -c 4 -u 5 -l 7 -o 7 -noABC >> results.txt
python3 aigen.py -bdd -output experiments/bdd_random_n3_4_5_7_7.aag -c 4 -u 5 -l 7 -o 7 -noABC >> results.txt

python3 aigen.py -dnf -output experiments/dnf_random_n1_4_5_7_7.aag -c 4 -u 5 -l 7 -o 7 -noABC >> results.txt
python3 aigen.py -dnf -output experiments/dnf_random_n2_4_5_7_7.aag -c 4 -u 5 -l 7 -o 7 -noABC >> results.txt
python3 aigen.py -dnf -output experiments/dnf_random_n3_4_5_7_7.aag -c 4 -u 5 -l 7 -o 7 -noABC >> results.txt

python3 aigen.py -bdd -output experiments/bdd_random_n1_6_4_8_8.aag -c 6 -u 4 -l 8 -o 8 -noABC >> results.txt
python3 aigen.py -bdd -output experiments/bdd_random_n2_6_4_8_8.aag -c 6 -u 4 -l 8 -o 8 -noABC >> results.txt
python3 aigen.py -bdd -output experiments/bdd_random_n3_6_4_8_8.aag -c 6 -u 4 -l 8 -o 8 -noABC >> results.txt

python3 aigen.py -dnf -output experiments/dnf_random_n1_6_4_8_8.aag -c 6 -u 4 -l 8 -o 8 -noABC >> results.txt
python3 aigen.py -dnf -output experiments/dnf_random_n2_6_4_8_8.aag -c 6 -u 4 -l 8 -o 8 -noABC >> results.txt
python3 aigen.py -dnf -output experiments/dnf_random_n3_6_4_8_8.aag -c 6 -u 4 -l 8 -o 8 -noABC >> results.txt

python3 aigen.py -bdd -output experiments/bdd_random_n1_6_7_6_6.aag -c 6 -u 7 -l 6 -o 6 -noABC >> results.txt
python3 aigen.py -bdd -output experiments/bdd_random_n2_6_7_6_6.aag -c 6 -u 7 -l 6 -o 6 -noABC >> results.txt
python3 aigen.py -bdd -output experiments/bdd_random_n3_6_7_6_6.aag -c 6 -u 7 -l 6 -o 6 -noABC >> results.txt

python3 aigen.py -dnf -output experiments/dnf_random_n1_6_7_6_6.aag -c 6 -u 7 -l 6 -o 6 -noABC >> results.txt
python3 aigen.py -dnf -output experiments/dnf_random_n2_6_7_6_6.aag -c 6 -u 7 -l 6 -o 6 -noABC >> results.txt
python3 aigen.py -dnf -output experiments/dnf_random_n3_6_7_6_6.aag -c 6 -u 7 -l 6 -o 6 -noABC >> results.txt


python3 aigen.py -bdd -output experiments/bdd_random_n1_8_8_4_4.aag -c 8 -u 8 -l 4 -o 4 -noABC >> results.txt
python3 aigen.py -bdd -output experiments/bdd_random_n2_8_8_4_4.aag -c 8 -u 8 -l 4 -o 4 -noABC >> results.txt
python3 aigen.py -bdd -output experiments/bdd_random_n3_8_8_4_4.aag -c 8 -u 8 -l 4 -o 4 -noABC >> results.txt

python3 aigen.py -dnf -output experiments/dnf_random_n1_8_8_4_4.aag -c 8 -u 8 -l 4 -o 4 -noABC >> results.txt
python3 aigen.py -dnf -output experiments/dnf_random_n2_8_8_4_4.aag -c 8 -u 8 -l 4 -o 4 -noABC >> results.txt
python3 aigen.py -dnf -output experiments/dnf_random_n3_8_8_4_4.aag -c 8 -u 8 -l 4 -o 4 -noABC >> results.txt

python ResultsToTex.py results.txt plots.tex
sudo apt install texlive-latex-base
pip3 install pdflatex
sudo apt-get install -y texlive-pictures
pdflatex plots.tex


