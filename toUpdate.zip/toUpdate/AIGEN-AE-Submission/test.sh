#!/bin/bash

codeLoc=""
if [ ! -e aigen.py ]
then
    codeLoc="AIGEN-AE-Submission/"
fi

> "$codeLoc"results.txt
> "$codeLoc"plots.tex

python3 "$codeLoc"aigen.py -bdd -output "$codeLoc"experiments/bdd_random_n1_4_4_7_7.aag -c 1 -u 1 -l 3 -o 3 >> "$codeLoc"results.txt


if [ -e ResultsToTex.py ]
then
    python3 ResultsToTex.py results.txt plots.tex
else
    python3 AIGEN-AE-Submission/ResultsToTex.py AIGEN-AE-Submission/results.txt AIGEN-AE-Submission/plots.tex
fi





